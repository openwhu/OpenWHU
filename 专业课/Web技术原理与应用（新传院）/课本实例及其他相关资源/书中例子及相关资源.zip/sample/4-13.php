<html>
	<head>
		<title>这是一个简单的PHP程序</title>
		<meta charset="utf-8">
	</head>
	<body>
	
<?php
	$a="Welcome to PHP World";
	echo $a;   //向客户端输出$a的内容
?>
   </body>
</html>