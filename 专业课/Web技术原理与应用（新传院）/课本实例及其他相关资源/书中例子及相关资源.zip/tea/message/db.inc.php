<?php
$conn=mysql_connect("localhost","tea","tea");
mysql_query("set names 'utf8'");
mysql_select_db("tea");